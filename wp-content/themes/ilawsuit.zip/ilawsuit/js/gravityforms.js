// This file gets the files below from gravityforms plugin and compiles a gravitforms-min.js file. I am combining those files, minimizing them, enqueuing this file, then deferring ths file for page speed

// @codekit-prepend '../../../plugins/gravityforms/js/jquery.json.js'
// @codekit-prepend '../../../plugins/gravityforms/js/gravityforms.min.js'
// @codekit-prepend '../../../plugins/gravityforms/js/jquery.maskedinput.min.js'
// @codekit-prepend '../../../plugins/gravityforms/js/placeholders.jquery.min.js'


