<form action="/" method="get">
    
    <input type="text" name="s" id="search" placeholder="Search Lawyers" value="<?php the_search_query(); ?>" />
    
    <div class="search_wrapper_inner">
    
    	<input type="submit" id="searchsubmit" value="Search">
    	
    	<div class="search_icon"></div><!-- search_icon -->
   
    </div><!-- search_wrapper -->

</form>



