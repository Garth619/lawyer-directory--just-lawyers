<?php get_header(); ?>



				
				<?php get_template_part( 'loop', 'single' );?>
				
			
			
			<?php get_sidebar('blog'); ?>
			
	


<?php get_footer(); ?>




