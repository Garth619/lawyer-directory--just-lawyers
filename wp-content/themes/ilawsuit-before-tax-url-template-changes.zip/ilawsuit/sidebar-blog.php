<?php // dynamic_sidebar( 'recent_posts' ); ?>

<?php // dynamic_sidebar( 'category_sidebar' ); ?>

<?php // dynamic_sidebar( 'archive_sidebar' ); ?>